## read CODA data from JAGS
# setwd("/home/chris/bugsbook/bugsbook_rsrc/examples/ch-implement-seeds")
library(coda)
seeds.coda <- read.openbugs("seeds")
summary(seeds.coda)
plot(seeds.coda)

## Convert existing WinBUGS data into JAGS format
bugs2jags("Seedsdata.txt","seeds-data.R")
source("seeds-data.R")
## Create an R data list to use in rjags
seeds <- list(r=r, n=n, x1=x1, x2=x2, N=N)

## Use rjags
library(rjags)
seeds.jags <- jags.model("Seedsmodel.txt", data=seeds, n.chains=2)
update(seeds.jags, 4000)
seeds.coda <- coda.samples(seeds.jags, c("alpha0","alpha1","alpha2","alpha12","sigma"), 10000)
summary(seeds.coda)
plot(seeds.coda)
