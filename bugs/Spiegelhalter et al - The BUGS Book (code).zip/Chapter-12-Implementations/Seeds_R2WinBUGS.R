library(R2WinBUGS)

#change working directory to wherever the model and data are stored.
#setwd("S:/WinBUGS14/Test")

model.file <- "Seeds_mod.txt"
data <- dget("Seeds_dat.txt")
inits <- list(
              list(alpha0 = 0, alpha1 = 0, alpha2 = 0, alpha12 = 0, tau = 1),
              list(alpha0 = 10, alpha1 = 10, alpha2 = 10, alpha12 = 10, tau = 0.1)
              ) 

inits <- function(){
    list(alpha0=rnorm(1, 0, 10), alpha1=rnorm(1, 0, 10), alpha2=rnorm(1, 0, 10),
         alpha12=rnorm(1, 0, 10), tau=runif(1, 0, 5))
}

parameters <- c("alpha0", "alpha1", "alpha2", "alpha12", "sigma")

# change the bugs.directory if your WinBUGS is installed somewhere
# other than the default "c:/Program Files/WinBUGS14/"

#seeds.sim <- bugs(data, inits, parameters, model.file,
#                  n.chains=2, n.iter=14000, n.burnin=4000,
#                  bugs.directory="c:/Program Files/WinBUGS14/")
seeds.sim <- bugs(data, inits, parameters, model.file,
                    n.chains=2, n.iter=14000, n.burnin=4000, n.thin=1,
                    bugs.directory="S:/WinBUGS14", debug=FALSE)

seeds.sim
plot(seeds.sim)

library("denstrip")

#setEPS()
## to save the plot to an EPS file, if necessary
#postscript("../../bugsbook/figs/ch-implement-seeds-rdemo.eps")

plot(0, type="n", xlim=c(0.1, 6), ylim=c(0,2.5), xlab="Odds ratio", 
         ylab="", log="x", yaxt="n", bty="n", cex.axis=1.5, cex.lab=1.5)
abline(v=1, col="lightgray", lty=2)
for (i in 1:3) { 
	sam <- exp(seeds.sim$sims.list[[i+1]])
	denstrip(sam, at=3-i, tick=quantile(sam, c(0.025, 0.975)),
            	mtick = median(sam))
}

text(0.1, 3:0 + 0.2,
     c(expression(paste("Seed type 73 (vs. 75): ", e^alpha[1])),
       expression(paste("Cucumber (vs. bean): ", e^alpha[2])),
       expression(paste("Interaction (73 and cucumber): ", e^alpha[12]))
       ),
     pos=4
     )

#dev.off()
