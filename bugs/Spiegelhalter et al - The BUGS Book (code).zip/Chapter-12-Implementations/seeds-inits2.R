"tau" <-
0.1
"alpha0" <-
1
"alpha1" <-
1
"alpha2" <-
1
"alpha12" <-
1
